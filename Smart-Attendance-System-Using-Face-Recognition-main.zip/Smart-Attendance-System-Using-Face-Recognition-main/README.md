# Smart-Attendance-System-Using-Face-Recognition
The Smart Attendance System is an AI-powered solution that automates the attendance marking process using facial recognition technology. This system eliminates the need for traditional roll calls or RFID-based systems, making attendance tracking more efficient, secure, and contactless.
